# FleetDash — Frontend

Live Map UI: a strict-TypeScript React app with a custom Canvas rendering
layer for thousands of concurrently moving vehicles.

## Setup
```bash
npm install
npm run dev   # http://localhost:5173
```

Set `VITE_SOCKET_URL` (e.g. in a `.env` file) if the backend isn't at
`http://localhost:4000`.

## Architecture Notes
- **Why Canvas, not DOM/SVG markers?** Rendering thousands of moving
  elements as React-managed DOM nodes causes layout thrash and garbage
  collection pressure at scale. A single `<canvas>` redrawn on a
  `requestAnimationFrame` loop keeps the viewport at a steady frame rate
  regardless of fleet size.
- **Why a `Map` ref instead of React state for vehicle positions?**
  `telemetry:batch` events can arrive dozens of times per second. Storing
  positions in a mutable `useRef` map — read directly by the rAF loop —
  means position updates never trigger a React re-render. Only UI chrome
  (FPS counter, selected vehicle panel, connection status) uses React state,
  and only updates a few times per second.
- **Binary decoding:** `useSocket` decodes the backend's compact 28-byte
  binary point format directly from the `ArrayBuffer`, using a roster map
  (`vehicleHash -> vehicleId`) synced once on connect, avoiding the cost of
  parsing a large JSON payload per frame.
