import { useEffect, useRef, useState } from 'react';
import { io, Socket } from 'socket.io-client';
import type { VehiclePoint, GeofenceAlert, RosterMap } from '../types';

const POINT_BYTES = 28;
const SOCKET_URL = (import.meta.env.VITE_SOCKET_URL as string | undefined) ?? 'http://localhost:4000';

/**
 * Decodes the binary ArrayBuffer wire format emitted by the backend's
 * Socket.io layer (see backend/src/services/socketServer.js) back into
 * a list of vehicle points. Runs entirely off React state until the
 * consumer decides to render, so decoding never triggers a re-render
 * per point.
 */
function decodeBuffer(buffer: ArrayBuffer, roster: RosterMap): VehiclePoint[] {
  const view = new DataView(buffer);
  const count = buffer.byteLength / POINT_BYTES;
  const points: VehiclePoint[] = [];
  const now = Date.now();

  for (let i = 0; i < count; i += 1) {
    const offset = i * POINT_BYTES;
    const hash = view.getUint32(offset);
    const lat = view.getFloat64(offset + 4);
    const lng = view.getFloat64(offset + 12);
    const speedKph = view.getFloat32(offset + 20);
    const heading = view.getFloat32(offset + 24);

    const vehicleId = roster[hash] ?? `#${hash}`;
    points.push({ vehicleId, lat, lng, speedKph, heading, updatedAt: now });
  }

  return points;
}

interface UseSocketResult {
  vehiclesRef: React.MutableRefObject<Map<string, VehiclePoint>>;
  alerts: GeofenceAlert[];
  connected: boolean;
}

/**
 * Maintains live vehicle positions in a mutable ref (NOT React state) so
 * that thousands of updates/sec never trigger a React re-render. The
 * Canvas layer reads from this ref directly inside its own
 * requestAnimationFrame loop.
 */
export function useSocket(): UseSocketResult {
  const vehiclesRef = useRef<Map<string, VehiclePoint>>(new Map());
  const rosterRef = useRef<RosterMap>({});
  const [alerts, setAlerts] = useState<GeofenceAlert[]>([]);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    const socket: Socket = io(SOCKET_URL, { transports: ['websocket'] });

    socket.on('connect', () => setConnected(true));
    socket.on('disconnect', () => setConnected(false));

    socket.on('roster:sync', (roster: RosterMap) => {
      rosterRef.current = { ...rosterRef.current, ...roster };
    });

    socket.on('telemetry:batch', (buffer: ArrayBuffer) => {
      const points = decodeBuffer(buffer, rosterRef.current);
      points.forEach((p) => vehiclesRef.current.set(p.vehicleId, p));
    });

    socket.on('geofence:alert', (alert: GeofenceAlert) => {
      setAlerts((prev) => [alert, ...prev].slice(0, 50));
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  return { vehiclesRef, alerts, connected };
}
