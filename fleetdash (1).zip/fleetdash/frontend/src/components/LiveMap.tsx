import { useEffect, useRef, useState } from 'react';
import type { VehiclePoint } from '../types';

interface LiveMapProps {
  vehiclesRef: React.MutableRefObject<Map<string, VehiclePoint>>;
  bounds: { minLat: number; maxLat: number; minLng: number; maxLng: number };
  onSelect: (vehicleId: string | null) => void;
  selectedId: string | null;
}

/**
 * Renders live vehicle positions on an HTML5 Canvas, driven entirely by
 * requestAnimationFrame reading straight out of a mutable ref. This
 * deliberately bypasses React state/reconciliation for the hot path —
 * with thousands of moving points, re-rendering a React tree per frame
 * would blow the frame budget and freeze the UI. The canvas is the one
 * place in this app allowed to "cheat" React's render cycle.
 */
export default function LiveMap({ vehiclesRef, bounds, onSelect, selectedId }: LiveMapProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const rafRef = useRef<number>(0);
  const [fps, setFps] = useState(0);
  const [vehicleCount, setVehicleCount] = useState(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let lastFrameTs = performance.now();
    let frameCount = 0;
    let fpsAccumulator = performance.now();

    function project(lat: number, lng: number, w: number, h: number) {
      const x = ((lng - bounds.minLng) / (bounds.maxLng - bounds.minLng)) * w;
      const y = h - ((lat - bounds.minLat) / (bounds.maxLat - bounds.minLat)) * h;
      return { x, y };
    }

    function drawGrid(w: number, h: number) {
      ctx!.strokeStyle = 'rgba(88, 166, 189, 0.08)';
      ctx!.lineWidth = 1;
      const step = 48;
      for (let x = 0; x < w; x += step) {
        ctx!.beginPath();
        ctx!.moveTo(x, 0);
        ctx!.lineTo(x, h);
        ctx!.stroke();
      }
      for (let y = 0; y < h; y += step) {
        ctx!.beginPath();
        ctx!.moveTo(0, y);
        ctx!.lineTo(w, y);
        ctx!.stroke();
      }
    }

    function frame(now: number) {
      const dpr = window.devicePixelRatio || 1;
      const w = canvas!.clientWidth;
      const h = canvas!.clientHeight;
      if (canvas!.width !== w * dpr || canvas!.height !== h * dpr) {
        canvas!.width = w * dpr;
        canvas!.height = h * dpr;
      }
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx!.clearRect(0, 0, w, h);

      // background
      ctx!.fillStyle = '#0a0e13';
      ctx!.fillRect(0, 0, w, h);
      drawGrid(w, h);

      const vehicles = vehiclesRef.current;
      let count = 0;

      vehicles.forEach((v) => {
        const { x, y } = project(v.lat, v.lng, w, h);
        if (x < -10 || x > w + 10 || y < -10 || y > h + 10) return;
        count += 1;

        const isSelected = v.vehicleId === selectedId;
        const isStale = now - v.updatedAt > 4000;
        const speedColor = isStale
          ? 'rgba(120,130,140,0.6)'
          : v.speedKph > 5
          ? '#34d5b0'
          : '#5b8def';

        // heading wedge
        ctx!.save();
        ctx!.translate(x, y);
        ctx!.rotate((v.heading * Math.PI) / 180);
        ctx!.beginPath();
        ctx!.moveTo(0, -7);
        ctx!.lineTo(4, 5);
        ctx!.lineTo(-4, 5);
        ctx!.closePath();
        ctx!.fillStyle = speedColor;
        ctx!.fill();
        ctx!.restore();

        if (isSelected) {
          ctx!.beginPath();
          ctx!.arc(x, y, 11, 0, Math.PI * 2);
          ctx!.strokeStyle = '#ff6a3d';
          ctx!.lineWidth = 2;
          ctx!.stroke();
        }
      });

      frameCount += 1;
      if (now - fpsAccumulator >= 1000) {
        setFps(frameCount);
        setVehicleCount(count);
        frameCount = 0;
        fpsAccumulator = now;
      }
      lastFrameTs = now;
      rafRef.current = requestAnimationFrame(frame);
    }

    rafRef.current = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(rafRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bounds, selectedId]);

  function handleClick(e: React.MouseEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;

    let closestId: string | null = null;
    let closestDist = 18; // px hit-radius

    vehiclesRef.current.forEach((v) => {
      const x = ((v.lng - bounds.minLng) / (bounds.maxLng - bounds.minLng)) * w;
      const y = h - ((v.lat - bounds.minLat) / (bounds.maxLat - bounds.minLat)) * h;
      const dist = Math.hypot(x - clickX, y - clickY);
      if (dist < closestDist) {
        closestDist = dist;
        closestId = v.vehicleId;
      }
    });

    onSelect(closestId);
  }

  return (
    <div className="live-map">
      <canvas ref={canvasRef} className="live-map__canvas" onClick={handleClick} />
      <div className="live-map__hud">
        <span className="live-map__hud-item">{vehicleCount.toLocaleString()} vehicles on screen</span>
        <span className="live-map__hud-item live-map__hud-item--fps">{fps} fps</span>
      </div>
    </div>
  );
}
