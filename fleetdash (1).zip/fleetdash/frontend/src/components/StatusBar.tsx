import type { VehiclePoint } from '../types';

interface StatusBarProps {
  connected: boolean;
  selected: VehiclePoint | null;
}

export default function StatusBar({ connected, selected }: StatusBarProps) {
  return (
    <header className="status-bar">
      <div className="status-bar__brand">
        <span className="status-bar__logo">FLEETDASH</span>
        <span className="status-bar__tag">Event-Driven Fleet Telemetry</span>
      </div>

      <div className="status-bar__selected">
        {selected ? (
          <>
            <span className="status-bar__selected-id">{selected.vehicleId}</span>
            <span className="status-bar__selected-detail">
              {selected.speedKph.toFixed(0)} km/h · heading {selected.heading.toFixed(0)}°
            </span>
          </>
        ) : (
          <span className="status-bar__selected-hint">Click a vehicle on the map for details</span>
        )}
      </div>

      <div className={`status-bar__conn status-bar__conn--${connected ? 'up' : 'down'}`}>
        <span className="status-bar__dot" />
        {connected ? 'LIVE' : 'RECONNECTING'}
      </div>
    </header>
  );
}
