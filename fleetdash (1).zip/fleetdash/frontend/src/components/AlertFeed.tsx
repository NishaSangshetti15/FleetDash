import type { GeofenceAlert } from '../types';

interface AlertFeedProps {
  alerts: GeofenceAlert[];
}

export default function AlertFeed({ alerts }: AlertFeedProps) {
  return (
    <div className="alert-feed">
      <div className="alert-feed__header">
        <span>Geofence Alerts</span>
        <span className="alert-feed__count">{alerts.length}</span>
      </div>
      <div className="alert-feed__list">
        {alerts.length === 0 && (
          <div className="alert-feed__empty">No breaches yet — the fleet is holding its lanes.</div>
        )}
        {alerts.map((a, i) => (
          <div
            key={`${a.vehicleId}-${a.ts}-${i}`}
            className={`alert-feed__item alert-feed__item--${a.type}`}
          >
            <div className="alert-feed__item-top">
              <span className="alert-feed__badge">{a.type === 'enter' ? 'ENTER' : 'EXIT'}</span>
              <span className="alert-feed__vehicle">{a.vehicleId}</span>
            </div>
            <div className="alert-feed__fence">{a.fenceName}</div>
            <div className="alert-feed__time">{new Date(a.ts).toLocaleTimeString()}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
