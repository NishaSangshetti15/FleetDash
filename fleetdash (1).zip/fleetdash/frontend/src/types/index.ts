export interface VehiclePoint {
  vehicleId: string;
  lat: number;
  lng: number;
  speedKph: number;
  heading: number;
  updatedAt: number; // client-side receipt timestamp (ms)
}

export interface GeofenceAlert {
  type: 'enter' | 'exit';
  fenceId: string;
  fenceName: string;
  vehicleId: string;
  lat: number;
  lng: number;
  ts: string;
}

export interface RosterMap {
  [vehicleHash: string]: string; // hash -> vehicleId
}
