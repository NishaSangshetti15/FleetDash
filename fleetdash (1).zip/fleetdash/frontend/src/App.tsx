import { useState } from 'react';
import { useSocket } from './hooks/useSocket';
import LiveMap from './components/LiveMap';
import AlertFeed from './components/AlertFeed';
import StatusBar from './components/StatusBar';
import './styles/app.css';

// Default viewport bounds — a ~1 degree box around Jaipur, Rajasthan,
// matching the simulator/load-test coordinate range. Swap for your fleet's
// actual operating region.
const BOUNDS = {
  minLat: 26.4,
  maxLat: 27.4,
  minLng: 75.3,
  maxLng: 76.3,
};

export default function App() {
  const { vehiclesRef, alerts, connected } = useSocket();
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const selectedVehicle = selectedId ? vehiclesRef.current.get(selectedId) ?? null : null;

  return (
    <div className="app">
      <StatusBar connected={connected} selected={selectedVehicle} />
      <div className="app__body">
        <LiveMap
          vehiclesRef={vehiclesRef}
          bounds={BOUNDS}
          selectedId={selectedId}
          onSelect={setSelectedId}
        />
        <AlertFeed alerts={alerts} />
      </div>
    </div>
  );
}
