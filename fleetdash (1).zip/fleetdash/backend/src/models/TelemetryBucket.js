const mongoose = require('mongoose');

/**
 * Bucket Pattern:
 * Instead of writing one document per coordinate ping (which would create
 * millions of tiny documents per day for a large fleet), we group all
 * readings for a single vehicle within a single hour into ONE document.
 *
 * This document is called a "bucket". Each new reading is appended to the
 * bucket's `readings` array via a single atomic $push, and counters are
 * maintained so we never have to COUNT or re-scan the array to know its size.
 *
 * Bucket key = vehicleId + hour-aligned timestamp (bucketStart)
 */
const ReadingSchema = new mongoose.Schema(
  {
    ts: { type: Date, required: true },
    lat: { type: Number, required: true },
    lng: { type: Number, required: true },
    speedKph: { type: Number, default: 0 },
    heading: { type: Number, default: 0 },
  },
  { _id: false }
);

const TelemetryBucketSchema = new mongoose.Schema(
  {
    vehicleId: { type: String, required: true, index: true },
    bucketStart: { type: Date, required: true }, // start of the hour window
    bucketGranularityMinutes: { type: Number, default: 60 },
    readingCount: { type: Number, default: 0 },
    readings: { type: [ReadingSchema], default: [] },
    lastLat: Number,
    lastLng: Number,
    lastTs: Date,
  },
  { timestamps: true }
);

// Compound unique index: one bucket per vehicle per hour window.
TelemetryBucketSchema.index({ vehicleId: 1, bucketStart: 1 }, { unique: true });
// Supports "give me the latest bucket for vehicle X" queries in <5ms.
TelemetryBucketSchema.index({ vehicleId: 1, lastTs: -1 });

/**
 * Aligns a Date down to the start of its bucket window.
 */
function alignToBucket(date, granularityMinutes = 60) {
  const ms = granularityMinutes * 60 * 1000;
  return new Date(Math.floor(date.getTime() / ms) * ms);
}

/**
 * Atomically append a single reading to the correct bucket, creating the
 * bucket document if it doesn't exist yet (upsert). This is the write path
 * used by the ingestion engine and is safe under high concurrency.
 */
TelemetryBucketSchema.statics.appendReading = async function appendReading(
  vehicleId,
  reading,
  granularityMinutes = 60
) {
  const bucketStart = alignToBucket(reading.ts, granularityMinutes);

  return this.findOneAndUpdate(
    { vehicleId, bucketStart },
    {
      $push: { readings: reading },
      $inc: { readingCount: 1 },
      $set: {
        lastLat: reading.lat,
        lastLng: reading.lng,
        lastTs: reading.ts,
        bucketGranularityMinutes: granularityMinutes,
      },
      $setOnInsert: { vehicleId, bucketStart },
    },
    { upsert: true, new: true }
  );
};

module.exports = mongoose.model('TelemetryBucket', TelemetryBucketSchema);
module.exports.alignToBucket = alignToBucket;
