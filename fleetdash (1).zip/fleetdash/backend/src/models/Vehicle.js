const mongoose = require('mongoose');

const VehicleSchema = new mongoose.Schema(
  {
    vehicleId: { type: String, required: true, unique: true, index: true },
    label: { type: String, default: '' },
    driverName: { type: String, default: '' },
    status: {
      type: String,
      enum: ['active', 'idle', 'offline'],
      default: 'active',
    },
    lastKnownLat: Number,
    lastKnownLng: Number,
    lastSeenAt: Date,
  },
  { timestamps: true }
);

module.exports = mongoose.model('Vehicle', VehicleSchema);
