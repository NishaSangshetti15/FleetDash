const mongoose = require('mongoose');

/**
 * Geofences are stored as GeoJSON Polygons so they can be fed directly
 * into Turf.js for boundary intersection checks.
 */
const GeofenceSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    // GeoJSON Polygon: coordinates = [ [ [lng, lat], [lng, lat], ... ] ]
    geometry: {
      type: {
        type: String,
        enum: ['Polygon'],
        default: 'Polygon',
      },
      coordinates: {
        type: [[[Number]]],
        required: true,
      },
    },
    alertOnEnter: { type: Boolean, default: true },
    alertOnExit: { type: Boolean, default: true },
  },
  { timestamps: true }
);

GeofenceSchema.index({ geometry: '2dsphere' });

module.exports = mongoose.model('Geofence', GeofenceSchema);
