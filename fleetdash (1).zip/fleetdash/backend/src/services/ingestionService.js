const TelemetryBucket = require('../models/TelemetryBucket');
const Vehicle = require('../models/Vehicle');
const redisPubSub = require('./redisPubSub');
const { checkBreach } = require('../geospatial/geofenceCheck');
const logger = require('../utils/logger');

const GRANULARITY_MINUTES = Number(process.env.TELEMETRY_BUCKET_GRANULARITY_MINUTES) || 60;

/**
 * Takes a batch of RAW pings, offloads parsing/validation to the
 * worker_threads pool, then for every valid reading:
 *   1. Appends it to the correct MongoDB bucket document (upsert, atomic).
 *   2. Runs it through the Turf.js geofence check for breach transitions.
 *   3. Publishes the point (and any breach alerts) to Redis, which the
 *      Socket.io layer fans out to connected dashboards.
 *
 * Returns a summary: { accepted, rejected }.
 */
async function ingestBatch(pool, rawBatch) {
  const { valid, rejected } = await pool.process(rawBatch);

  await Promise.all(
    valid.map(async ({ vehicleId, reading }) => {
      // 1. Durable write using the Bucket Pattern.
      TelemetryBucket.appendReading(vehicleId, reading, GRANULARITY_MINUTES).catch((err) =>
        logger.error(`Bucket write failed for ${vehicleId}: ${err.message}`)
      );

      Vehicle.findOneAndUpdate(
        { vehicleId },
        {
          $set: {
            lastKnownLat: reading.lat,
            lastKnownLng: reading.lng,
            lastSeenAt: reading.ts,
            status: 'active',
          },
        },
        { upsert: true }
      ).catch((err) => logger.error(`Vehicle upsert failed for ${vehicleId}: ${err.message}`));

      // 2. Geofence breach detection (Turf.js, in-memory cache — fast path).
      const breaches = checkBreach(vehicleId, reading.lat, reading.lng, reading.ts);
      breaches.forEach((event) => redisPubSub.publishAlert(event));

      // 3. Broadcast the raw point to the message broker for live map fan-out.
      redisPubSub.publishTelemetry({
        vehicleId,
        lat: reading.lat,
        lng: reading.lng,
        speedKph: reading.speedKph,
        heading: reading.heading,
        ts: reading.ts,
      });
    })
  );

  if (rejected.length > 0) {
    logger.warn(`Ingestion batch rejected ${rejected.length} malformed ping(s)`);
  }

  return { accepted: valid.length, rejected: rejected.length };
}

module.exports = { ingestBatch };
