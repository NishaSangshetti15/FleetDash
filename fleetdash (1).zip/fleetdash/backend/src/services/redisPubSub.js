const Redis = require('ioredis');
const logger = require('../utils/logger');

const TELEMETRY_CHANNEL = 'fleetdash:telemetry';
const ALERT_CHANNEL = 'fleetdash:alerts';

function buildRedisOptions() {
  return {
    host: process.env.REDIS_HOST || '127.0.0.1',
    port: Number(process.env.REDIS_PORT) || 6379,
    password: process.env.REDIS_PASSWORD || undefined,
    lazyConnect: false,
  };
}

/**
 * Redis Pub/Sub layer.
 *
 * Why Redis sits between ingestion and Socket.io:
 * The ingestion path (worker_threads -> Mongo bucket writes) should never be
 * blocked or slowed down by however many Socket.io clients are currently
 * connected/broadcasting. Publishing to Redis is a fire-and-forget, O(1)
 * operation. Any number of Socket.io server instances (e.g. behind a load
 * balancer, horizontally scaled) can subscribe to the same channel and fan
 * the update out to their own connected clients. This decouples raw
 * ingestion throughput from client notification fan-out.
 */
class RedisPubSub {
  constructor() {
    this.publisher = new Redis(buildRedisOptions());
    this.subscriber = new Redis(buildRedisOptions());

    this.publisher.on('error', (err) => logger.error(`Redis publisher error: ${err.message}`));
    this.subscriber.on('error', (err) => logger.error(`Redis subscriber error: ${err.message}`));
  }

  publishTelemetry(update) {
    // update: { vehicleId, lat, lng, speedKph, heading, ts }
    return this.publisher.publish(TELEMETRY_CHANNEL, JSON.stringify(update));
  }

  publishAlert(alert) {
    // alert: { type: 'enter'|'exit', fenceId, fenceName, vehicleId, lat, lng, ts }
    return this.publisher.publish(ALERT_CHANNEL, JSON.stringify(alert));
  }

  onTelemetry(handler) {
    this.subscriber.subscribe(TELEMETRY_CHANNEL);
    this.subscriber.on('message', (channel, message) => {
      if (channel === TELEMETRY_CHANNEL) {
        try {
          handler(JSON.parse(message));
        } catch (err) {
          logger.error(`Failed to parse telemetry message: ${err.message}`);
        }
      }
    });
  }

  onAlert(handler) {
    this.subscriber.subscribe(ALERT_CHANNEL);
    this.subscriber.on('message', (channel, message) => {
      if (channel === ALERT_CHANNEL) {
        try {
          handler(JSON.parse(message));
        } catch (err) {
          logger.error(`Failed to parse alert message: ${err.message}`);
        }
      }
    });
  }
}

module.exports = new RedisPubSub();
module.exports.TELEMETRY_CHANNEL = TELEMETRY_CHANNEL;
module.exports.ALERT_CHANNEL = ALERT_CHANNEL;
