const { Server } = require('socket.io');
const logger = require('../utils/logger');
const redisPubSub = require('./redisPubSub');

/**
 * Binary wire format for a single telemetry point, broadcast to clients as
 * a raw ArrayBuffer instead of JSON. This drastically cuts payload size and
 * serialization cost when thousands of points move every second.
 *
 * Layout (28 bytes per point):
 *   [0]   uint32  vehicleHash   (hashed vehicleId -> looked up client-side)
 *   [4]   float64 lat
 *   [12]  float64 lng
 *   [20]  float32 speedKph
 *   [24]  float32 heading
 *
 * The client maintains its own vehicleId <-> hash table (built from a
 * one-time JSON "roster" event on connect), so hot updates never need to
 * carry string IDs over the wire.
 */
const POINT_BYTES = 28;

function hashVehicleId(vehicleId) {
  let hash = 0;
  for (let i = 0; i < vehicleId.length; i += 1) {
    hash = (hash * 31 + vehicleId.charCodeAt(i)) >>> 0;
  }
  return hash;
}

function encodePointsToBuffer(points) {
  const buffer = new ArrayBuffer(points.length * POINT_BYTES);
  const view = new DataView(buffer);

  points.forEach((p, i) => {
    const offset = i * POINT_BYTES;
    view.setUint32(offset, hashVehicleId(p.vehicleId));
    view.setFloat64(offset + 4, p.lat);
    view.setFloat64(offset + 12, p.lng);
    view.setFloat32(offset + 20, p.speedKph || 0);
    view.setFloat32(offset + 24, p.heading || 0);
  });

  return buffer;
}

/**
 * Batches inbound telemetry updates and flushes them to all connected
 * clients on a fixed interval (default ~50ms / 20fps), rather than emitting
 * a socket event per single point. This is what lets the frontend Canvas
 * layer stay smooth instead of thrashing on thousands of tiny emits/sec.
 */
function createSocketServer(httpServer) {
  const io = new Server(httpServer, {
    cors: {
      origin: process.env.SOCKET_CORS_ORIGIN || '*',
      methods: ['GET', 'POST'],
    },
    // Keep default engine.io framing; the *payload* itself is binary.
  });

  let pendingPoints = [];
  const vehicleIdByHash = new Map();

  redisPubSub.onTelemetry((update) => {
    vehicleIdByHash.set(hashVehicleId(update.vehicleId), update.vehicleId);
    pendingPoints.push(update);
  });

  redisPubSub.onAlert((alert) => {
    io.emit('geofence:alert', alert);
  });

  const FLUSH_INTERVAL_MS = 50;
  setInterval(() => {
    if (pendingPoints.length === 0) return;
    const buffer = encodePointsToBuffer(pendingPoints);
    io.emit('telemetry:batch', buffer);
    pendingPoints = [];
  }, FLUSH_INTERVAL_MS);

  io.on('connection', (socket) => {
    logger.info(`Client connected: ${socket.id}`);

    // Send the roster mapping so the client can decode vehicleHash -> vehicleId.
    socket.emit('roster:sync', Object.fromEntries(vehicleIdByHash));

    socket.on('disconnect', () => {
      logger.info(`Client disconnected: ${socket.id}`);
    });
  });

  return io;
}

module.exports = { createSocketServer, hashVehicleId, encodePointsToBuffer, POINT_BYTES };
