const turf = require('@turf/turf');

// We test the pure breach-detection logic in isolation by mocking the
// Geofence model so no real MongoDB connection is required.
jest.mock('../models/Geofence', () => ({
  find: () => ({
    lean: async () => [
      {
        _id: 'fence-1',
        name: 'Downtown Depot',
        alertOnEnter: true,
        alertOnExit: true,
        geometry: {
          type: 'Polygon',
          coordinates: [
            [
              [75.78, 26.9],
              [75.8, 26.9],
              [75.8, 26.92],
              [75.78, 26.92],
              [75.78, 26.9],
            ],
          ],
        },
      },
    ],
  }),
}));

const { refreshGeofenceCache, checkBreach } = require('../geospatial/geofenceCheck');

describe('Geofence breach detection (Turf.js)', () => {
  beforeAll(async () => {
    await refreshGeofenceCache();
  });

  it('emits an "enter" event the first time a vehicle enters a fence', () => {
    const events = checkBreach('truck-1', 26.91, 75.79); // inside the polygon
    expect(events).toHaveLength(1);
    expect(events[0].type).toBe('enter');
    expect(events[0].fenceName).toBe('Downtown Depot');
  });

  it('does not re-emit "enter" on a subsequent ping still inside the fence', () => {
    const events = checkBreach('truck-1', 26.911, 75.791); // still inside
    expect(events).toHaveLength(0);
  });

  it('emits an "exit" event when the vehicle leaves the fence', () => {
    const events = checkBreach('truck-1', 27.5, 76.5); // far outside
    expect(events).toHaveLength(1);
    expect(events[0].type).toBe('exit');
  });

  it('never flags a vehicle that never enters the fence', () => {
    const events = checkBreach('truck-2', 0, 0);
    expect(events).toHaveLength(0);
  });
});
