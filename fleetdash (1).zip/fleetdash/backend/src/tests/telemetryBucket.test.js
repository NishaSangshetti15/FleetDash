const { alignToBucket } = require('../models/TelemetryBucket');

describe('TelemetryBucket bucket-alignment (Bucket Pattern)', () => {
  it('aligns a timestamp down to the start of its hour window', () => {
    const date = new Date('2026-07-09T14:37:22.123Z');
    const aligned = alignToBucket(date, 60);
    expect(aligned.toISOString()).toBe('2026-07-09T14:00:00.000Z');
  });

  it('supports non-hour granularities (e.g. 15 minute buckets)', () => {
    const date = new Date('2026-07-09T14:37:22.123Z');
    const aligned = alignToBucket(date, 15);
    expect(aligned.toISOString()).toBe('2026-07-09T14:30:00.000Z');
  });

  it('two readings in the same hour align to the same bucket', () => {
    const a = alignToBucket(new Date('2026-07-09T14:01:00.000Z'), 60);
    const b = alignToBucket(new Date('2026-07-09T14:59:00.000Z'), 60);
    expect(a.getTime()).toBe(b.getTime());
  });
});
