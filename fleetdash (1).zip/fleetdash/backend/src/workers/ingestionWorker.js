const { parentPort } = require('worker_threads');

/**
 * Ingestion Worker
 * -----------------
 * Runs on a separate OS thread (via worker_threads). Its only job is to take
 * a RAW batch of telemetry pings (as sent by vehicles/simulators) and turn
 * them into validated, normalized reading objects.
 *
 * This keeps JSON parsing, validation, and normalization completely off the
 * main Node.js event loop, so the primary thread stays free to accept new
 * connections and serve Socket.io frames without blocking, even under
 * thousands of pings/sec.
 */

function isFiniteNumber(n) {
  return typeof n === 'number' && Number.isFinite(n);
}

function validateAndNormalize(rawPing) {
  const { vehicleId, lat, lng, speedKph, heading, ts } = rawPing;

  if (typeof vehicleId !== 'string' || vehicleId.length === 0) return null;
  if (!isFiniteNumber(lat) || lat < -90 || lat > 90) return null;
  if (!isFiniteNumber(lng) || lng < -180 || lng > 180) return null;

  return {
    vehicleId,
    reading: {
      ts: ts ? new Date(ts) : new Date(),
      lat,
      lng,
      speedKph: isFiniteNumber(speedKph) ? speedKph : 0,
      heading: isFiniteNumber(heading) ? heading : 0,
    },
  };
}

parentPort.on('message', (batch) => {
  // batch: array of raw pings, e.g. [{ vehicleId, lat, lng, speedKph, heading, ts }, ...]
  const valid = [];
  const rejected = [];

  for (const rawPing of batch) {
    const normalized = validateAndNormalize(rawPing);
    if (normalized) {
      valid.push(normalized);
    } else {
      rejected.push(rawPing);
    }
  }

  parentPort.postMessage({ valid, rejected });
});
