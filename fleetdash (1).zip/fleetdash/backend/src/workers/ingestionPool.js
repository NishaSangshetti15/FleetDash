const path = require('path');
const { Worker } = require('worker_threads');
const logger = require('../utils/logger');

/**
 * A minimal round-robin worker pool. Each worker is a long-lived thread
 * running ingestionWorker.js. We hand it a batch of raw pings and get back
 * { valid, rejected } once it's done parsing/validating.
 */
class IngestionPool {
  constructor(size = 4) {
    this.size = size;
    this.workers = [];
    this.nextIndex = 0;

    for (let i = 0; i < size; i += 1) {
      const worker = new Worker(path.join(__dirname, 'ingestionWorker.js'));
      worker.on('error', (err) => logger.error(`Ingestion worker ${i} error: ${err.message}`));
      worker.on('exit', (code) => {
        if (code !== 0) logger.warn(`Ingestion worker ${i} exited with code ${code}`);
      });
      this.workers.push(worker);
    }

    logger.info(`Ingestion worker pool started with ${size} thread(s)`);
  }

  /**
   * Sends a batch of raw pings to the next worker in round-robin order and
   * resolves with the { valid, rejected } result.
   */
  process(batch) {
    return new Promise((resolve, reject) => {
      const worker = this.workers[this.nextIndex];
      this.nextIndex = (this.nextIndex + 1) % this.size;

      const onMessage = (result) => {
        worker.off('message', onMessage);
        worker.off('error', onError);
        resolve(result);
      };
      const onError = (err) => {
        worker.off('message', onMessage);
        worker.off('error', onError);
        reject(err);
      };

      worker.once('message', onMessage);
      worker.once('error', onError);
      worker.postMessage(batch);
    });
  }

  async shutdown() {
    await Promise.all(this.workers.map((w) => w.terminate()));
  }
}

module.exports = IngestionPool;
