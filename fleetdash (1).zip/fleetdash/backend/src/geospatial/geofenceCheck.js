const turf = require('@turf/turf');
const Geofence = require('../models/Geofence');
const logger = require('../utils/logger');

/**
 * In-memory cache of geofences as Turf feature objects. Refreshed
 * periodically (or on demand) so the hot ingestion path never has to hit
 * MongoDB just to run a point-in-polygon check.
 */
let cachedFences = [];

async function refreshGeofenceCache() {
  const fences = await Geofence.find({}).lean();
  cachedFences = fences.map((f) => ({
    id: String(f._id),
    name: f.name,
    alertOnEnter: f.alertOnEnter,
    alertOnExit: f.alertOnExit,
    feature: turf.polygon(f.geometry.coordinates),
  }));
  logger.info(`Geofence cache refreshed: ${cachedFences.length} fence(s) loaded`);
  return cachedFences;
}

/**
 * Tracks which fences each vehicle was last known to be inside, so we can
 * detect enter/exit *transitions* rather than re-alerting on every ping.
 * vehicleId -> Set<fenceId>
 */
const vehicleFenceState = new Map();

/**
 * Given a vehicle's new coordinate, determine which fences it is now inside,
 * diff against its previous known state, and return a list of breach events
 * ({ type: 'enter' | 'exit', fenceId, fenceName, vehicleId, lat, lng, ts }).
 */
function checkBreach(vehicleId, lat, lng, ts = new Date()) {
  const point = turf.point([lng, lat]);
  const currentlyInside = new Set();

  for (const fence of cachedFences) {
    if (turf.booleanPointInPolygon(point, fence.feature)) {
      currentlyInside.add(fence.id);
    }
  }

  const previouslyInside = vehicleFenceState.get(vehicleId) || new Set();
  const events = [];

  for (const fence of cachedFences) {
    const isNowInside = currentlyInside.has(fence.id);
    const wasInside = previouslyInside.has(fence.id);

    if (isNowInside && !wasInside && fence.alertOnEnter) {
      events.push({
        type: 'enter',
        fenceId: fence.id,
        fenceName: fence.name,
        vehicleId,
        lat,
        lng,
        ts,
      });
    } else if (!isNowInside && wasInside && fence.alertOnExit) {
      events.push({
        type: 'exit',
        fenceId: fence.id,
        fenceName: fence.name,
        vehicleId,
        lat,
        lng,
        ts,
      });
    }
  }

  vehicleFenceState.set(vehicleId, currentlyInside);
  return events;
}

module.exports = {
  refreshGeofenceCache,
  checkBreach,
};
