require('dotenv').config();
const http = require('http');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

const connectDB = require('./config/db');
const logger = require('./utils/logger');
const IngestionPool = require('./workers/ingestionPool');
const { createSocketServer } = require('./services/socketServer');
const { refreshGeofenceCache } = require('./geospatial/geofenceCheck');

const telemetryRoutes = require('./routes/telemetry');
const vehicleRoutes = require('./routes/vehicles');
const geofenceRoutes = require('./routes/geofences');

async function main() {
  await connectDB();
  await refreshGeofenceCache();

  const pool = new IngestionPool(Number(process.env.INGESTION_WORKER_POOL_SIZE) || 4);

  const app = express();
  app.use(helmet());
  app.use(cors({ origin: process.env.SOCKET_CORS_ORIGIN || '*' }));
  app.use(express.json({ limit: '5mb' }));
  app.use(morgan('dev'));

  app.get('/health', (req, res) => res.json({ status: 'ok', uptime: process.uptime() }));

  app.use('/api/telemetry', telemetryRoutes(pool));
  app.use('/api/vehicles', vehicleRoutes);
  app.use('/api/geofences', geofenceRoutes);

  const httpServer = http.createServer(app);
  createSocketServer(httpServer);

  const PORT = process.env.PORT || 4000;
  httpServer.listen(PORT, () => {
    logger.info(`FleetDash backend listening on port ${PORT}`);
  });

  process.on('SIGINT', async () => {
    logger.info('Shutting down...');
    await pool.shutdown();
    process.exit(0);
  });
}

main().catch((err) => {
  logger.error(`Fatal startup error: ${err.message}`);
  process.exit(1);
});
