const express = require('express');
const Geofence = require('../models/Geofence');
const { refreshGeofenceCache } = require('../geospatial/geofenceCheck');

const router = express.Router();

// GET /api/geofences
router.get('/', async (req, res) => {
  const fences = await Geofence.find({}).lean();
  res.json(fences);
});

// POST /api/geofences
// Body: { name, coordinates: [[lng,lat], ...], alertOnEnter, alertOnExit }
router.post('/', async (req, res) => {
  const { name, coordinates, alertOnEnter = true, alertOnExit = true } = req.body;

  if (!name || !Array.isArray(coordinates) || coordinates.length < 3) {
    return res.status(400).json({ error: 'name and a coordinates ring (>=3 points) are required' });
  }

  // Ensure the polygon ring is closed (first point === last point).
  const ring = [...coordinates];
  const [firstLng, firstLat] = ring[0];
  const [lastLng, lastLat] = ring[ring.length - 1];
  if (firstLng !== lastLng || firstLat !== lastLat) {
    ring.push(ring[0]);
  }

  const fence = await Geofence.create({
    name,
    geometry: { type: 'Polygon', coordinates: [ring] },
    alertOnEnter,
    alertOnExit,
  });

  await refreshGeofenceCache();
  res.status(201).json(fence);
});

// DELETE /api/geofences/:id
router.delete('/:id', async (req, res) => {
  await Geofence.findByIdAndDelete(req.params.id);
  await refreshGeofenceCache();
  res.status(204).end();
});

module.exports = router;
