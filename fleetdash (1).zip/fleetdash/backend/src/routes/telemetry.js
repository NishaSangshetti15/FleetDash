const express = require('express');
const { ingestBatch } = require('../services/ingestionService');

module.exports = function telemetryRoutes(pool) {
  const router = express.Router();

  /**
   * POST /api/telemetry
   * Body: { pings: [{ vehicleId, lat, lng, speedKph, heading, ts }, ...] }
   *
   * Accepts a batch of raw coordinate pings from vehicles/simulators.
   * Parsing/validation happens on a worker thread; this route handler
   * returns as soon as the batch has been handed off + processed.
   */
  router.post('/', async (req, res) => {
    const { pings } = req.body;

    if (!Array.isArray(pings) || pings.length === 0) {
      return res.status(400).json({ error: 'pings must be a non-empty array' });
    }

    try {
      const result = await ingestBatch(pool, pings);
      return res.status(202).json(result);
    } catch (err) {
      return res.status(500).json({ error: 'ingestion failed', detail: err.message });
    }
  });

  return router;
};
