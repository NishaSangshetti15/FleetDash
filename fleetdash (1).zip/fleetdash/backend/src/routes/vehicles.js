const express = require('express');
const Vehicle = require('../models/Vehicle');
const TelemetryBucket = require('../models/TelemetryBucket');

const router = express.Router();

// GET /api/vehicles - list all known vehicles with last known position.
router.get('/', async (req, res) => {
  const vehicles = await Vehicle.find({}).lean();
  res.json(vehicles);
});

// GET /api/vehicles/:vehicleId/history?hours=1 - recent bucket history.
router.get('/:vehicleId/history', async (req, res) => {
  const { vehicleId } = req.params;
  const hours = Number(req.query.hours) || 1;
  const since = new Date(Date.now() - hours * 60 * 60 * 1000);

  const buckets = await TelemetryBucket.find({
    vehicleId,
    bucketStart: { $gte: since },
  })
    .sort({ bucketStart: 1 })
    .lean();

  res.json(buckets);
});

module.exports = router;
