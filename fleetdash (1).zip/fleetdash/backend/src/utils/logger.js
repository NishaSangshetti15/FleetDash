const levels = ['error', 'warn', 'info', 'debug'];

function timestamp() {
  return new Date().toISOString();
}

function log(level, message) {
  if (!levels.includes(level)) level = 'info';
  // eslint-disable-next-line no-console
  console.log(`[${timestamp()}] [${level.toUpperCase()}] ${message}`);
}

module.exports = {
  error: (msg) => log('error', msg),
  warn: (msg) => log('warn', msg),
  info: (msg) => log('info', msg),
  debug: (msg) => log('debug', msg),
};
