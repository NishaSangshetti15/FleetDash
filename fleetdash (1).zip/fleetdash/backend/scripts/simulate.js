/* eslint-disable no-console */
require('dotenv').config();
const http = require('http');

/**
 * Simulates a fleet of vehicles sending coordinate pings to the ingestion
 * API. Useful for exercising the full pipeline (worker_threads -> Mongo
 * bucket writes -> Turf.js geofence checks -> Redis -> Socket.io) without
 * needing real hardware.
 *
 * Usage: node scripts/simulate.js [vehicleCount] [intervalMs]
 */
const BASE_URL = process.env.BASE_URL || 'http://localhost:4000';
const VEHICLE_COUNT = Number(process.argv[2]) || 200;
const INTERVAL_MS = Number(process.argv[3]) || 500;

// Center around Jaipur, Rajasthan, matching the sample geofence.
const CENTER = { lat: 26.9124, lng: 75.7873 };

const vehicles = Array.from({ length: VEHICLE_COUNT }, (_, i) => ({
  vehicleId: `truck-${i}`,
  lat: CENTER.lat + (Math.random() - 0.5) * 0.6,
  lng: CENTER.lng + (Math.random() - 0.5) * 0.6,
  heading: Math.random() * 360,
  speedKph: 20 + Math.random() * 60,
}));

function step(v) {
  const radians = (v.heading * Math.PI) / 180;
  const distanceDeg = (v.speedKph / 3600) * INTERVAL_MS * 0.00001;
  v.lat += Math.cos(radians) * distanceDeg;
  v.lng += Math.sin(radians) * distanceDeg;
  v.heading += (Math.random() - 0.5) * 15;
  v.speedKph = Math.max(0, Math.min(120, v.speedKph + (Math.random() - 0.5) * 5));
}

function postBatch(pings) {
  const data = JSON.stringify({ pings });
  const url = new URL('/api/telemetry', BASE_URL);

  const req = http.request(
    {
      hostname: url.hostname,
      port: url.port,
      path: url.pathname,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(data),
      },
    },
    (res) => {
      res.on('data', () => {});
    }
  );

  req.on('error', (err) => console.error(`Simulator POST failed: ${err.message}`));
  req.write(data);
  req.end();
}

console.log(`Simulating ${VEHICLE_COUNT} vehicles -> ${BASE_URL}/api/telemetry every ${INTERVAL_MS}ms`);

setInterval(() => {
  const pings = vehicles.map((v) => {
    step(v);
    return {
      vehicleId: v.vehicleId,
      lat: v.lat,
      lng: v.lng,
      speedKph: v.speedKph,
      heading: v.heading,
      ts: new Date().toISOString(),
    };
  });
  postBatch(pings);
}, INTERVAL_MS);
