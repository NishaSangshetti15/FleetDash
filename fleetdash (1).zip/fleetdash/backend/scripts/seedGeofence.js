/* eslint-disable no-console */
require('dotenv').config();
const mongoose = require('mongoose');
const Geofence = require('../src/models/Geofence');

/**
 * Seeds a sample geofence ring around the simulator's operating area
 * (Jaipur, Rajasthan) so geofence breach alerts have something to trigger
 * against out of the box.
 */
async function main() {
  await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/fleetdash');

  const ring = [
    [75.75, 26.86],
    [75.85, 26.86],
    [75.85, 26.96],
    [75.75, 26.96],
    [75.75, 26.86],
  ];

  const existing = await Geofence.findOne({ name: 'Jaipur Central Depot' });
  if (existing) {
    console.log('Sample geofence already exists, skipping.');
  } else {
    const fence = await Geofence.create({
      name: 'Jaipur Central Depot',
      geometry: { type: 'Polygon', coordinates: [ring] },
      alertOnEnter: true,
      alertOnExit: true,
    });
    console.log('Seeded geofence:', fence._id.toString());
  }

  await mongoose.disconnect();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
