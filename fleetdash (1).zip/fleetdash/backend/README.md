# FleetDash — Backend

High-throughput, event-driven fleet telemetry ingestion service.

## Stack
- Node.js + Express
- `worker_threads` — offloads parsing/validation of raw coordinate batches
- MongoDB + Mongoose — **Bucket Pattern** storage (one doc per vehicle per hour)
- Redis (ioredis) — Pub/Sub message broker decoupling ingestion from broadcast
- Socket.io — binary (`ArrayBuffer`) live position broadcast to dashboards
- Turf.js — geofence boundary intersection / breach detection

## Setup
```bash
cp .env.example .env
npm install
# requires a running MongoDB and Redis instance (see .env)
npm run dev
```

## Key Endpoints
| Method | Path                              | Description                          |
|--------|-----------------------------------|---------------------------------------|
| POST   | `/api/telemetry`                  | Ingest a batch of raw coordinate pings |
| GET    | `/api/vehicles`                   | List vehicles + last known position   |
| GET    | `/api/vehicles/:id/history?hours=1` | Bucketed telemetry history           |
| GET    | `/api/geofences`                  | List geofences                        |
| POST   | `/api/geofences`                  | Create a geofence (GeoJSON ring)      |
| DELETE | `/api/geofences/:id`              | Remove a geofence                     |
| GET    | `/health`                         | Health check                          |

## Socket.io Events (client-facing)
- `roster:sync` — one-time map of `vehicleHash -> vehicleId` on connect
- `telemetry:batch` — binary `ArrayBuffer`, 28 bytes/point, flushed ~20x/sec
- `geofence:alert` — JSON breach event `{ type: 'enter'|'exit', vehicleId, fenceName, ... }`

## Testing
```bash
npm test
```

## Load Testing
Validates the Mid-Project Review target: **2,000 req/sec, zero data omission**.
```bash
npm run loadtest   # requires k6 installed: https://k6.io/docs/get-started/installation/
```

## Architecture Notes
- **Why worker_threads?** Parsing/validating thousands of pings/sec on the
  main thread would starve the event loop that also has to serve Socket.io
  frames. The ingestion pool isolates that CPU-bound work.
- **Why the Bucket Pattern?** Writing one Mongo document per coordinate ping
  would create an unmanageable number of tiny documents. Grouping readings
  into one document per vehicle per hour keeps writes as fast atomic
  `$push` operations and keeps read queries (e.g. "last hour of history for
  truck-42") to a single document fetch.
- **Why Redis between ingestion and Socket.io?** So ingestion throughput is
  never coupled to however much broadcast fan-out is happening, and so the
  Socket.io layer can be horizontally scaled independently.
