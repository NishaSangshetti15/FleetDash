import http from 'k6/http';
import { check, sleep } from 'k6';

/**
 * k6 load test for the /api/telemetry ingestion endpoint.
 * Mid-Project Review target: 2,000 req/sec ingestion with zero data omission.
 *
 * Run with: k6 run loadtest/ingestion.k6.js
 */
export const options = {
  scenarios: {
    fleet_ingestion: {
      executor: 'constant-arrival-rate',
      rate: 2000, // 2000 iterations per second
      timeUnit: '1s',
      duration: '30s',
      preAllocatedVUs: 200,
      maxVUs: 500,
    },
  },
  thresholds: {
    http_req_duration: ['p(95)<50'],
    http_req_failed: ['rate<0.001'],
  },
};

const BASE_URL = __ENV.BASE_URL || 'http://localhost:4000';

function randomPing(i) {
  return {
    vehicleId: `truck-${i % 500}`,
    lat: 26.9124 + (Math.random() - 0.5) * 0.5,
    lng: 75.7873 + (Math.random() - 0.5) * 0.5,
    speedKph: Math.random() * 100,
    heading: Math.random() * 360,
    ts: new Date().toISOString(),
  };
}

export default function () {
  const batch = [];
  for (let i = 0; i < 10; i += 1) {
    batch.push(randomPing(i + __VU * 10));
  }

  const res = http.post(
    `${BASE_URL}/api/telemetry`,
    JSON.stringify({ pings: batch }),
    { headers: { 'Content-Type': 'application/json' } }
  );

  check(res, {
    'status is 202': (r) => r.status === 202,
  });

  sleep(0.001);
}
