# FleetDash

**High-Throughput Event-Driven Fleet Telemetry Dashboard**
Project 1 of the Infotact Solutions MERN Stack Development series.

> Logistics companies struggle with tracking thousands of concurrent
> vehicles in real time. FleetDash ingests high-frequency coordinate
> updates off the main thread, stores them efficiently, detects geofence
> breaches, and renders a live 60fps map — without dropping a single point.

## Monorepo Layout
```
fleetdash/
├── backend/     Node.js/Express API, worker_threads ingestion, Redis pub/sub,
│                 MongoDB (Bucket Pattern), Turf.js geofencing, Socket.io
├── frontend/    React + TypeScript, Canvas-based live map, binary decode
└── docker-compose.yml   Local MongoDB + Redis
```

## Key Modules (per spec)
| Module | Implementation |
|---|---|
| Ingestion Engine | `backend/src/workers/ingestionWorker.js` + `ingestionPool.js` (worker_threads) |
| Database Layer | `backend/src/models/TelemetryBucket.js` (MongoDB Bucket Pattern) |
| Message Broker | `backend/src/services/redisPubSub.js` + `socketServer.js` (Redis Pub/Sub, binary Socket.io transport) |
| Live Map UI | `frontend/src/components/LiveMap.tsx` (Canvas + requestAnimationFrame) |
| Geospatial Rules | `backend/src/geospatial/geofenceCheck.js` (Turf.js boundary checks) |

## Quick Start
```bash
# 1. Start MongoDB + Redis
docker compose up -d

# 2. Backend
cd backend
cp .env.example .env
npm install
npm run seed      # creates a sample geofence around Jaipur
npm run dev        # http://localhost:4000

# 3. Simulate a fleet (separate terminal)
npm run simulate   # 200 vehicles pinging every 500ms

# 4. Frontend (separate terminal)
cd ../frontend
npm install
npm run dev         # http://localhost:5173
```

Open http://localhost:5173 — you should see simulated vehicles moving on
the live Canvas map, with geofence enter/exit alerts appearing in the side
panel as vehicles cross the seeded "Jaipur Central Depot" boundary.

## Testing & Benchmarking
```bash
cd backend
npm test          # Jest + Supertest (bucket pattern + geofence logic)
npm run loadtest   # k6: targets 2,000 req/sec, zero data omission
```

## Week-wise plan, technology stack, and delivery standards
See the original project brief (`PROJECT.pdf`, Project 1) for the full
4-week agile breakdown, Mid-Project and Final Review criteria.
